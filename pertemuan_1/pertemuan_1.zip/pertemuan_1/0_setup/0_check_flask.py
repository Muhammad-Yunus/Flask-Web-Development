import flask

print("Flask Version :", flask.__version__)