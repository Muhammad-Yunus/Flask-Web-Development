# Most common configuration
DEBUG = True
SQLALCHEMY_ECHO = False

