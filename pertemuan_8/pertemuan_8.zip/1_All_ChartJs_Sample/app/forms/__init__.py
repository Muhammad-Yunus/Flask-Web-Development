from datetime import datetime
from flask_wtf import FlaskForm
from wtforms import BooleanField, StringField, TextAreaField, \
                    IntegerField, SelectMultipleField, PasswordField, \
                    validators, SubmitField, DateTimeField, FloatField